package com.example.examination.util

object Constants {
    const val PREFS_NAME = "MyPref"
    const val EMAIL = "email"
    const val PASS = "pass"
}